/**
 * Componente MoistureCard
 * 
 * Exibe a umidade do solo de uma área específica (Norte ou Sul)
 * Mostra: percentual de umidade, barra de progresso, status e ícone
 * 
 * Props:
 * - area: string - Nome da área (ex: "Parte Norte")
 * - moisture: number - Percentual de umidade (0-100)
 * - icon: ReactNode - Ícone a ser exibido
 */

import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";

interface MoistureCardProps {
  area: string;
  moisture: number;
  icon: React.ReactNode;
}

export function MoistureCard({ area, moisture, icon }: MoistureCardProps) {
  // Determina o status do solo baseado no percentual de umidade
  const getStatus = (value: number) => {
    if (value < 30) return { text: "Solo seco", color: "bg-destructive text-destructive-foreground" };
    if (value >= 30 && value <= 70) return { text: "Umidade ideal", color: "bg-[#2d7a4f] text-white" };
    return { text: "Solo úmido", color: "bg-[#52b788] text-white" };
  };

  const status = getStatus(moisture);

  // Determina a cor da barra de progresso
  const getProgressColor = (value: number) => {
    if (value < 30) return "bg-destructive";
    if (value >= 30 && value <= 70) return "bg-[#2d7a4f]";
    return "bg-[#52b788]";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-border/50">
        <CardHeader className="space-y-1 pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl">{area}</CardTitle>
            <div className="text-primary opacity-80">{icon}</div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Percentual grande de umidade */}
          <div className="text-center">
            <motion.div
              key={moisture}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="text-6xl font-bold text-primary"
            >
              {moisture}%
            </motion.div>
            <p className="text-sm text-muted-foreground mt-1">Umidade do solo</p>
          </div>

          {/* Barra de progresso animada */}
          <div className="space-y-2">
            <Progress 
              value={moisture} 
              className="h-3 bg-muted"
              indicatorClassName={getProgressColor(moisture)}
            />
          </div>

          {/* Badge de status */}
          <div className="flex justify-center">
            <Badge className={`${status.color} px-4 py-1.5`}>
              {status.text}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
