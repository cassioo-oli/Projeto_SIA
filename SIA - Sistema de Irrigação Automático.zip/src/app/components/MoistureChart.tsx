/**
 * Componente MoistureChart
 * 
 * Exibe gráfico de linha com o histórico de umidade
 * Mostra dados separados para área Norte e Sul
 * Usa recharts para renderização do gráfico
 * 
 * Props:
 * - data: array de objetos com time, north e south
 */

import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface ChartDataPoint {
  time: string;
  north: number;
  south: number;
}

interface MoistureChartProps {
  data: ChartDataPoint[];
}

export function MoistureChart({ data }: MoistureChartProps) {
  return (
    <Card className="shadow-lg border-border/50">
      <CardHeader>
        <CardTitle className="text-xl">Histórico de Umidade</CardTitle>
        <p className="text-sm text-muted-foreground">Variação nas últimas horas</p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1F4D3A20" />
            <XAxis 
              dataKey="time" 
              stroke="#1F4D3A"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#1F4D3A"
              style={{ fontSize: '12px' }}
              domain={[0, 100]}
              label={{ value: '%', position: 'insideLeft', style: { fill: '#1F4D3A' } }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#ffffff', 
                border: '1px solid #1F4D3A20',
                borderRadius: '8px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
              }}
              labelStyle={{ color: '#1F4D3A', fontWeight: 'bold' }}
            />
            <Legend 
              wrapperStyle={{ paddingTop: '20px' }}
              iconType="line"
            />
            <Line 
              type="monotone" 
              dataKey="north" 
              stroke="#2d7a4f" 
              strokeWidth={2.5}
              name="Parte Norte"
              dot={{ fill: '#2d7a4f', r: 4 }}
              activeDot={{ r: 6 }}
            />
            <Line 
              type="monotone" 
              dataKey="south" 
              stroke="#52b788" 
              strokeWidth={2.5}
              name="Parte Sul"
              dot={{ fill: '#52b788', r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
