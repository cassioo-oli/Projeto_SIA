/**
 * Componente StatusPanel
 * 
 * Exibe informações gerais do sistema:
 * - Status da bomba (ligada/desligada)
 * - Temperatura ambiente
 * - Última atualização
 * - Alertas de umidade baixa
 * 
 * Props:
 * - pumpStatus: boolean - Status da bomba (true = ligada)
 * - temperature: number - Temperatura em °C
 * - lastUpdate: string - Horário da última atualização
 * - hasAlert: boolean - Se há alerta de umidade baixa
 */

import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { Power, Thermometer, Clock, AlertTriangle } from "lucide-react";

interface StatusPanelProps {
  pumpStatus: boolean;
  temperature: number;
  lastUpdate: string;
  hasAlert: boolean;
}

export function StatusPanel({ pumpStatus, temperature, lastUpdate, hasAlert }: StatusPanelProps) {
  return (
    <Card className="shadow-lg border-border/50">
      <CardHeader>
        <CardTitle className="text-xl">Status Geral do Sistema</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Status da bomba */}
        <div className="flex items-center justify-between p-3 bg-accent rounded-lg">
          <div className="flex items-center gap-3">
            <Power className={`h-5 w-5 ${pumpStatus ? 'text-[#2d7a4f]' : 'text-muted-foreground'}`} />
            <div>
              <p className="font-medium text-sm">Bomba de Irrigação</p>
              <p className="text-xs text-muted-foreground">Sistema de bombeamento</p>
            </div>
          </div>
          <Badge className={pumpStatus ? "bg-[#2d7a4f] text-white" : "bg-muted text-muted-foreground"}>
            {pumpStatus ? "Ligada" : "Desligada"}
          </Badge>
        </div>

        {/* Temperatura */}
        <div className="flex items-center justify-between p-3 bg-accent rounded-lg">
          <div className="flex items-center gap-3">
            <Thermometer className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium text-sm">Temperatura Ambiente</p>
              <p className="text-xs text-muted-foreground">Sensor local</p>
            </div>
          </div>
          <span className="text-2xl font-bold text-primary">{temperature}°C</span>
        </div>

        {/* Última atualização */}
        <div className="flex items-center justify-between p-3 bg-accent rounded-lg">
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium text-sm">Última Atualização</p>
              <p className="text-xs text-muted-foreground">Sincronização de dados</p>
            </div>
          </div>
          <span className="text-sm font-medium text-primary">{lastUpdate}</span>
        </div>

        {/* Alerta de umidade baixa */}
        {hasAlert && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-3 p-3 bg-destructive/10 border border-destructive/20 rounded-lg"
          >
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <div>
              <p className="font-medium text-sm text-destructive">Alerta de Umidade</p>
              <p className="text-xs text-destructive/80">Uma ou mais áreas com umidade abaixo de 30%</p>
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
