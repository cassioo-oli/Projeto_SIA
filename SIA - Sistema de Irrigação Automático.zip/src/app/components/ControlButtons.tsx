/**
 * Componente ControlButtons
 * 
 * Exibe botões para controle do sistema de irrigação:
 * - Ligar irrigação manual
 * - Desligar irrigação
 * - Modo automático
 * 
 * Props:
 * - onTurnOn: função chamada ao ligar irrigação
 * - onTurnOff: função chamada ao desligar irrigação
 * - onAutoMode: função chamada ao ativar modo automático
 * - isAutoMode: boolean indicando se está em modo automático
 */

import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Power, PowerOff, Zap } from "lucide-react";

interface ControlButtonsProps {
  onTurnOn: () => void;
  onTurnOff: () => void;
  onAutoMode: () => void;
  isAutoMode: boolean;
}

export function ControlButtons({ onTurnOn, onTurnOff, onAutoMode, isAutoMode }: ControlButtonsProps) {
  return (
    <Card className="shadow-lg border-border/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">Controle de Irrigação</CardTitle>
          {isAutoMode && (
            <Badge className="bg-[#2d7a4f] text-white">
              Modo Automático
            </Badge>
          )}
        </div>
        <p className="text-sm text-muted-foreground">Gerencie o sistema manualmente ou automaticamente</p>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Botão Ligar Irrigação */}
        <Button
          onClick={onTurnOn}
          disabled={isAutoMode}
          className="w-full bg-[#2d7a4f] hover:bg-[#1F4D3A] text-white h-12 transition-all duration-200 disabled:opacity-50"
        >
          <Power className="mr-2 h-5 w-5" />
          Ligar Irrigação
        </Button>

        {/* Botão Desligar Irrigação */}
        <Button
          onClick={onTurnOff}
          disabled={isAutoMode}
          variant="outline"
          className="w-full border-[#1F4D3A] text-[#1F4D3A] hover:bg-[#1F4D3A] hover:text-white h-12 transition-all duration-200 disabled:opacity-50"
        >
          <PowerOff className="mr-2 h-5 w-5" />
          Desligar Irrigação
        </Button>

        {/* Botão Modo Automático */}
        <Button
          onClick={onAutoMode}
          variant={isAutoMode ? "default" : "secondary"}
          className={`w-full h-12 transition-all duration-200 ${
            isAutoMode 
              ? 'bg-[#52b788] hover:bg-[#2d7a4f] text-white' 
              : 'bg-accent text-accent-foreground hover:bg-[#2d7a4f] hover:text-white'
          }`}
        >
          <Zap className="mr-2 h-5 w-5" />
          {isAutoMode ? "Desativar Modo Automático" : "Ativar Modo Automático"}
        </Button>
      </CardContent>
    </Card>
  );
}
