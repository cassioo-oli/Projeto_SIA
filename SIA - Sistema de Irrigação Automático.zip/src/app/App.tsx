/**
 * Sistema de Irrigação Inteligente
 * 
 * Aplicação principal que monitora a umidade do solo em tempo real
 * e controla o sistema de irrigação automática.
 * 
 * Funcionalidades:
 * - Monitoramento de umidade em duas áreas (Norte e Sul)
 * - Controle manual e automático da bomba
 * - Gráfico histórico de umidade
 * - Alertas de umidade baixa
 * - Atualização em tempo real (simulada)
 * 
 * Preparado para integração futura com:
 * - Arduino (sensores de umidade)
 * - Node.js + Socket.io (comunicação em tempo real)
 * 
 * Para integração futura via WebSocket:
 * socket.on("umidade", (dados) => {
 *   setMoistureNorth(dados.north);
 *   setMoistureSouth(dados.south);
 *   setTemperature(dados.temperature);
 * });
 */

import { useState, useEffect } from "react";
import { MoistureCard } from "./components/MoistureCard";
import { StatusPanel } from "./components/StatusPanel";
import { MoistureChart } from "./components/MoistureChart";
import { ControlButtons } from "./components/ControlButtons";
import { Sprout, Droplets, Leaf } from "lucide-react";
import { motion } from "motion/react";

// Interface para dados do gráfico
interface ChartDataPoint {
  time: string;
  north: number;
  south: number;
}

export default function App() {
  // Estados para umidade das áreas
  const [moistureNorth, setMoistureNorth] = useState(45);
  const [moistureSouth, setMoistureSouth] = useState(55);
  
  // Estados para controle do sistema
  const [pumpStatus, setPumpStatus] = useState(false);
  const [isAutoMode, setIsAutoMode] = useState(false);
  const [temperature, setTemperature] = useState(24);
  const [lastUpdate, setLastUpdate] = useState("");
  
  // Estado para dados do gráfico
  const [chartData, setChartData] = useState<ChartDataPoint[]>([
    { time: "00:00", north: 65, south: 70 },
    { time: "04:00", north: 55, south: 65 },
    { time: "08:00", north: 48, south: 58 },
    { time: "12:00", north: 42, south: 52 },
    { time: "16:00", north: 45, south: 55 },
    { time: "20:00", north: 45, south: 55 },
  ]);

  // Atualiza horário da última atualização
  const updateTime = () => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    setLastUpdate(`${hours}:${minutes}:${seconds}`);
  };

  // Simula atualização de dados em tempo real
  // Em produção, esta função será substituída por dados reais via Socket.io
  useEffect(() => {
    updateTime();
    
    const interval = setInterval(() => {
      // Simula variação de umidade (-2 a +2)
      setMoistureNorth(prev => {
        const newValue = prev + (Math.random() * 4 - 2);
        return Math.max(0, Math.min(100, newValue));
      });
      
      setMoistureSouth(prev => {
        const newValue = prev + (Math.random() * 4 - 2);
        return Math.max(0, Math.min(100, newValue));
      });
      
      // Simula variação de temperatura (-1 a +1)
      setTemperature(prev => {
        const newValue = prev + (Math.random() * 2 - 1);
        return Math.max(15, Math.min(35, newValue));
      });
      
      updateTime();
    }, 5000); // Atualiza a cada 5 segundos

    return () => clearInterval(interval);
  }, []);

  // Atualiza gráfico quando umidade muda
  useEffect(() => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const timeStr = `${hours}:${minutes}`;
    
    setChartData(prev => {
      const newData = [...prev.slice(-5), {
        time: timeStr,
        north: Math.round(moistureNorth),
        south: Math.round(moistureSouth),
      }];
      return newData;
    });
  }, [moistureNorth, moistureSouth]);

  // Modo automático: liga bomba se umidade < 35%
  useEffect(() => {
    if (isAutoMode) {
      const needsWater = moistureNorth < 35 || moistureSouth < 35;
      setPumpStatus(needsWater);
    }
  }, [isAutoMode, moistureNorth, moistureSouth]);

  // Verifica se há alerta de umidade baixa
  const hasAlert = moistureNorth < 30 || moistureSouth < 30;

  // Handlers para botões de controle
  const handleTurnOn = () => {
    setPumpStatus(true);
    console.log("Bomba ligada manualmente");
    // Aqui seria enviado comando para o Arduino/Node.js
    // socket.emit("controle", { acao: "ligar" });
  };

  const handleTurnOff = () => {
    setPumpStatus(false);
    console.log("Bomba desligada manualmente");
    // Aqui seria enviado comando para o Arduino/Node.js
    // socket.emit("controle", { acao: "desligar" });
  };

  const handleAutoMode = () => {
    setIsAutoMode(prev => !prev);
    console.log(`Modo automático ${!isAutoMode ? "ativado" : "desativado"}`);
    // Aqui seria enviado comando para o Arduino/Node.js
    // socket.emit("controle", { acao: "automatico", valor: !isAutoMode });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4"
          >
            <div className="p-3 bg-[#2d7a4f] rounded-xl">
              <Sprout className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-primary">
                SIA - Sistema de Irrigação Automático
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Monitoramento em tempo real da plantação
              </p>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {/* Cards de Umidade - Norte e Sul */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <MoistureCard
              area="Parte Norte"
              moisture={Math.round(moistureNorth)}
              icon={<Droplets className="h-8 w-8" />}
            />
            <MoistureCard
              area="Parte Sul"
              moisture={Math.round(moistureSouth)}
              icon={<Leaf className="h-8 w-8" />}
            />
          </div>

          {/* Status Geral */}
          <StatusPanel
            pumpStatus={pumpStatus}
            temperature={Math.round(temperature * 10) / 10}
            lastUpdate={lastUpdate}
            hasAlert={hasAlert}
          />

          {/* Gráfico de Histórico */}
          <MoistureChart data={chartData} />

          {/* Botões de Controle */}
          <ControlButtons
            onTurnOn={handleTurnOn}
            onTurnOff={handleTurnOff}
            onAutoMode={handleAutoMode}
            isAutoMode={isAutoMode}
          />

          {/* Footer informativo */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-center py-6"
          >
            <p className="text-sm text-muted-foreground">
              Sistema IoT de Automação Agrícola • Atualização automática a cada 5 segundos
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Desenvolvido para integração com Arduino e Node.js
            </p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
