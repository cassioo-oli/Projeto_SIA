
  # SIA - Sistema de Irrigação Automático

  This is a code bundle for SIA - Sistema de Irrigação Automático. The original project is available at https://www.figma.com/design/IEGJxKNdtHRsBsYsZk1otM/SIA---Sistema-de-Irriga%C3%A7%C3%A3o-Autom%C3%A1tico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  