# 🌱 Sistema de Irrigação Inteligente

## 📋 Visão Geral

Sistema web moderno e responsivo para monitoramento e controle de irrigação automática, desenvolvido com React, TypeScript e Tailwind CSS. O projeto simula o monitoramento em tempo real de umidade do solo e controle de bomba de irrigação, preparado para integração futura com Arduino e Node.js.

## 🎨 Design

### Paleta de Cores
- **Fundo**: `#F7F5EF` (Creme claro)
- **Principal**: `#1F4D3A` (Verde escuro)
- **Acento 1**: `#2d7a4f` (Verde médio)
- **Acento 2**: `#52b788` (Verde claro)
- **Cards**: `#FFFFFF` (Branco)

### Características Visuais
- ✨ Design minimalista e clean
- 📱 Mobile-first, totalmente responsivo
- 🎯 Bordas arredondadas
- 💫 Sombras suaves
- 🔄 Animações fluidas
- 🎭 Transições modernas

## 🏗️ Estrutura do Projeto

```
src/
├── app/
│   ├── App.tsx                      # Componente principal
│   └── components/
│       ├── MoistureCard.tsx         # Card de umidade (Norte/Sul)
│       ├── StatusPanel.tsx          # Painel de status geral
│       ├── MoistureChart.tsx        # Gráfico de histórico
│       ├── ControlButtons.tsx       # Botões de controle
│       └── ui/                      # Componentes de UI reutilizáveis
└── styles/
    ├── theme.css                    # Variáveis de tema
    └── tailwind.css                 # Configuração Tailwind
```

## 🎯 Funcionalidades

### 1. Monitoramento de Umidade
- 📊 Duas áreas de monitoramento (Norte e Sul)
- 💧 Percentual de umidade em tempo real
- 📈 Barra de progresso visual animada
- 🏷️ Status do solo:
  - Solo seco (< 30%)
  - Umidade ideal (30-70%)
  - Solo úmido (> 70%)

### 2. Status do Sistema
- 🔌 Status da bomba (ligada/desligada)
- 🌡️ Temperatura ambiente
- 🕐 Última atualização
- ⚠️ Alertas de umidade baixa

### 3. Gráfico Histórico
- 📉 Visualização de dados históricos
- 🎨 Linhas separadas para cada área
- 🔄 Atualização automática

### 4. Controles
- ▶️ Ligar irrigação (manual)
- ⏹️ Desligar irrigação (manual)
- ⚡ Modo automático (irrigação inteligente)

## 🔧 Tecnologias Utilizadas

- **React 18** - Framework JavaScript
- **TypeScript** - Tipagem estática
- **Tailwind CSS v4** - Estilização
- **Recharts** - Gráficos
- **Lucide React** - Ícones
- **Motion** (Framer Motion) - Animações
- **Radix UI** - Componentes acessíveis

## 🚀 Como Executar

1. **Instalar dependências**:
```bash
pnpm install
```

2. **Executar em desenvolvimento**:
```bash
pnpm dev
```

3. **Build para produção**:
```bash
pnpm build
```

## 🔌 Integração com Arduino e Node.js

### Preparação para Integração Real

O código está preparado para receber dados reais via WebSocket (Socket.io). Veja os pontos de integração:

#### 1. Backend Node.js + Socket.io

Crie um servidor Node.js:

```javascript
// server.js
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "http://localhost:5173", // URL do React
    methods: ["GET", "POST"]
  }
});

// Conectar com Arduino via Serial
const port = new SerialPort({ path: '/dev/ttyUSB0', baudRate: 9600 });
const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

// Receber dados do Arduino
parser.on('data', (data) => {
  try {
    const dados = JSON.parse(data);
    // Enviar dados para todos os clientes conectados
    io.emit('umidade', {
      north: dados.umidadeNorte,
      south: dados.umidadeSul,
      temperature: dados.temperatura
    });
  } catch (error) {
    console.error('Erro ao processar dados:', error);
  }
});

// Receber comandos do frontend
io.on('connection', (socket) => {
  console.log('Cliente conectado');
  
  socket.on('controle', (comando) => {
    // Enviar comando para Arduino
    port.write(JSON.stringify(comando) + '\n');
  });
  
  socket.on('disconnect', () => {
    console.log('Cliente desconectado');
  });
});

server.listen(3001, () => {
  console.log('Servidor rodando na porta 3001');
});
```

#### 2. Código Arduino

```cpp
// arduino_irrigation.ino
#include <ArduinoJson.h>

// Pinos dos sensores de umidade
const int sensorNorte = A0;
const int sensorSul = A1;

// Pino da bomba/relé
const int pinoBomba = 7;

// Pino do sensor de temperatura (DHT11/DHT22)
const int pinoTemp = 2;

void setup() {
  Serial.begin(9600);
  pinMode(pinoBomba, OUTPUT);
  digitalWrite(pinoBomba, LOW);
}

void loop() {
  // Ler sensores de umidade (0-1023)
  int leituraNorte = analogRead(sensorNorte);
  int leituraSul = analogRead(sensorSul);
  
  // Converter para percentual (0-100%)
  // Calibração: solo seco = 1023, solo molhado = 300
  int umidadeNorte = map(leituraNorte, 1023, 300, 0, 100);
  int umidadeSul = map(leituraSul, 1023, 300, 0, 100);
  
  // Garantir valores entre 0-100
  umidadeNorte = constrain(umidadeNorte, 0, 100);
  umidadeSul = constrain(umidadeSul, 0, 100);
  
  // Ler temperatura (simplificado)
  float temperatura = 24.5; // Implementar leitura real do DHT
  
  // Criar JSON
  StaticJsonDocument<200> doc;
  doc["umidadeNorte"] = umidadeNorte;
  doc["umidadeSul"] = umidadeSul;
  doc["temperatura"] = temperatura;
  
  // Enviar via Serial
  serializeJson(doc, Serial);
  Serial.println();
  
  // Receber comandos do Node.js
  if (Serial.available() > 0) {
    String comando = Serial.readStringUntil('\n');
    
    StaticJsonDocument<200> docComando;
    deserializeJson(docComando, comando);
    
    String acao = docComando["acao"];
    
    if (acao == "ligar") {
      digitalWrite(pinoBomba, HIGH);
    } else if (acao == "desligar") {
      digitalWrite(pinoBomba, LOW);
    } else if (acao == "automatico") {
      bool ativar = docComando["valor"];
      // Implementar lógica de modo automático
    }
  }
  
  delay(5000); // Enviar dados a cada 5 segundos
}
```

#### 3. Frontend React (App.tsx)

Adicione no componente App.tsx:

```typescript
import { useEffect } from 'react';
import { io } from 'socket.io-client';

export default function App() {
  // ... estados existentes ...

  useEffect(() => {
    // Conectar ao servidor Socket.io
    const socket = io('http://localhost:3001');

    // Receber dados de umidade em tempo real
    socket.on('umidade', (dados) => {
      setMoistureNorth(dados.north);
      setMoistureSouth(dados.south);
      setTemperature(dados.temperature);
    });

    // Limpar conexão ao desmontar
    return () => {
      socket.disconnect();
    };
  }, []);

  const handleTurnOn = () => {
    socket.emit('controle', { acao: 'ligar' });
    setPumpStatus(true);
  };

  const handleTurnOff = () => {
    socket.emit('controle', { acao: 'desligar' });
    setPumpStatus(false);
  };

  const handleAutoMode = () => {
    socket.emit('controle', { 
      acao: 'automatico', 
      valor: !isAutoMode 
    });
    setIsAutoMode(!isAutoMode);
  };

  // ... resto do código ...
}
```

### Pacotes Necessários

```bash
# Backend
npm install express socket.io serialport @serialport/parser-readline

# Frontend (já instalado)
npm install socket.io-client
```

## 📊 Dados Simulados vs Dados Reais

### Atualmente (Simulação)
- ✅ Dados de umidade variam aleatoriamente
- ✅ Temperatura varia levemente
- ✅ Atualização a cada 5 segundos
- ✅ Modo automático funciona localmente

### Com Integração Real
- 🔧 Dados virão dos sensores Arduino
- 🔧 Comandos serão enviados para relé/bomba
- 🔧 Comunicação via WebSocket em tempo real
- 🔧 Modo automático executado no Arduino

## 🎓 Para Apresentação Escolar/TCC

### Pontos de Destaque

1. **Interface Moderna**: Design profissional e responsivo
2. **Tecnologia IoT**: Integração hardware + software
3. **Sustentabilidade**: Economia de água através de automação
4. **Escalabilidade**: Fácil adicionar mais sensores/áreas
5. **Tempo Real**: Monitoramento instantâneo via WebSocket

### Melhorias Futuras

- 📱 App mobile nativo (React Native)
- 🔔 Notificações push de alertas
- 📧 Relatórios por email
- ☁️ Armazenamento em nuvem (banco de dados)
- 🤖 Machine Learning para previsão de irrigação
- 🌦️ Integração com API de clima
- 📷 Câmeras para monitoramento visual
- 💾 Histórico de dados de longo prazo

## 📱 Responsividade

O sistema foi desenvolvido com abordagem mobile-first:

- **Mobile** (< 768px): Layout em coluna única
- **Tablet** (768px - 1024px): Grid 2 colunas para cards
- **Desktop** (> 1024px): Layout otimizado em grid

## 🎨 Customização

Para alterar cores, edite `/src/styles/theme.css`:

```css
:root {
  --background: #F7F5EF;        /* Cor de fundo */
  --foreground: #1F4D3A;        /* Cor do texto */
  --primary: #1F4D3A;           /* Cor principal */
  --chart-1: #2d7a4f;           /* Cor gráfico Norte */
  --chart-2: #52b788;           /* Cor gráfico Sul */
}
```

## 📄 Licença

Este projeto foi desenvolvido para fins educacionais.

## 👨‍💻 Autor

Sistema desenvolvido para projeto de TCC/escola - Monitoramento de Irrigação Automática

---

**Nota**: Este é um sistema funcional e visualmente atraente, pronto para demonstração. Para uso em produção real, implemente validações de segurança, tratamento de erros mais robusto e testes adequados.
